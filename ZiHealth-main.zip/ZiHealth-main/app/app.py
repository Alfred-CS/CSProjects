from flask import Flask, flash, request, redirect, render_template, url_for, send_file, send_from_directory, abort, session
from flask_session import Session
import re
import mysql.connector
import os
import pymysql
from email_validator import validate_email

app = Flask(__name__)

app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)
app.config.update({
    'SECRET_KEY': 'supersecretkey',
})

@app.route("/", methods=['GET', 'POST']) 
# No Route Takes User to Login Page
def main():
    return redirect('/login')

@app.route("/logout")
def logout():
    session["name"] = None
    return redirect('/login')

@app.route("/home", methods=['GET', 'POST']) 
# Home Page
def home():
    if not session.get("name"):
        return redirect('/login')

    return render_template('home.html')

@app.route("/login", methods=['GET', 'POST']) 
# Login Page
def login():

    #DB credentials
    if request.method == 'POST':
        ENDPOINT = "hospitaldatabase.c9us8upioch7.us-east-1.rds.amazonaws.com"
        PORT = "3306"
        USER = "ablevy96"
        REGION = "us-east-1"
        DBNAME = "HospitalDatabase"
        os.environ['LIBMYSQL_ENABLE_CLEARTEXT_PLUGIN'] = '1'

        #Read from the front end
        doc = request.form.to_dict(flat=False)

        username = doc["username"][0]
        user_password = doc["password"][0]

        #connect to mysql
        db = pymysql.connect(
            host=ENDPOINT, user=USER,
            password="Learning613", port=3306, db = DBNAME)
       

        checkUser = " "
        checkPass = " "

        cur = db.cursor()
        query = ("SELECT * FROM staff_info")
        cur.execute(query)
        result = cur.fetchall()
        for row in result:
            for i in row:
                print(i)
                if i == username:
                    print(i)
                    checkUser = i
                elif i == user_password:
                    print(i)
                    checkPass = i
                else:
                    continue
            cur.close()
            if checkUser == username and checkPass == user_password:
                session["name"] = username
                return render_template('home.html', row = row)
        # ALERT FOR FAILED LOGIN
        else:
            flash("Username and Password Do Not Match")
        db.close()
    return render_template('login.html')

@app.route("/newPatient", methods=['GET', 'POST']) 
# New Patient Page
def newPatient():
    if not session.get("name"):
        return redirect('/login')
    
    if request.method == 'POST':
        
        ENDPOINT = "hospitaldatabase.c9us8upioch7.us-east-1.rds.amazonaws.com"
        PORT = "3306"
        USER = "ablevy96"
        REGION = "us-east-1"
        DBNAME = "HospitalDatabase"
        os.environ['LIBMYSQL_ENABLE_CLEARTEXT_PLUGIN'] = '1'

        #connect to mysql
        new_patient = pymysql.connect(
            host=ENDPOINT, user=USER,
            password="Learning613", port=3306, db=DBNAME)

        doc = request.form.to_dict(flat=False)

        firstName = doc['firstName'][0]
        lastName = doc['lastName'][0]
        address = doc['address'][0]
        date = doc['admitDate'][0]
        iopatient = doc['status'][0]
        insurance = doc['insurance'][0]
        ssn = doc['ssn'][0]
        valid = checkSSN(ssn)
        if not valid:
            flash("SSN Invalid")
            return redirect('/newPatient')
        doctor_id = doc['physician'][0]

        # Check if patient exists
        np_cursor = new_patient.cursor()
        query = ("SELECT * FROM staff_info")
        np_cursor.execute(query)
        result = np_cursor.fetchall()
        for row in result:
            for i in row:
                if i == ssn:
                    print(i)
                    return render_template('login.html')

        #add patient
        sql = "INSERT INTO Patient (patient_id, first_name, last_name, address, DATE_FORMAT, IOPatient, insurance, doctor_id, SSN) VALUES (%s, %s, %s, %s, %s, %s, %s, %s,%s)"
        val = ('{0}',

            firstName,
            lastName,
            address,
            date,
            iopatient,
            insurance,
            doctor_id,
            ssn)
        
        np_cursor.execute(sql, val)
        new_patient.commit()
        result = np_cursor.fetchall()
        
        app.logger.info(result)
        print(result)
        for row in result:
            for i in row:
                if str(i) == ssn:
                    return render_template('home.html')
                np_cursor.close()
    return render_template('newpatient.html')

@app.route("/newStaff", methods=['GET', 'POST'])
# New Staff Page
def newStaff():
    if not session.get("name"):
        return redirect('/login')

    if request.method == 'POST':
        
        ENDPOINT = "hospitaldatabase.c9us8upioch7.us-east-1.rds.amazonaws.com"
        PORT = "3306"
        USER = "ablevy96"
        REGION = "us-east-1"
        DBNAME = "HospitalDatabase"
        os.environ['LIBMYSQL_ENABLE_CLEARTEXT_PLUGIN'] = '1'

        #connect to mysql
        new_staff_db = pymysql.connect(
            host=ENDPOINT, user=USER,
            password="Learning613", port=3306, db=DBNAME)
    
        doc = request.form.to_dict(flat=False)

        firstName = doc['firstName'][0]
        lastName = doc['lastName'][0]
        ssn = doc['ssn'][0]
        valid = checkSSN(ssn)
        if not valid:
            flash("SSN Invalid")
            return redirect('/newStaff')
        staffType = doc['type'][0]
        address = doc['address'][0]
        certification = doc['certification'][0]
        certExp = doc['certExp'][0]
        phoneNumber = doc['phone'][0]
        valid = checkNumber(phoneNumber)
        if not valid:
            flash("Phone Number Invalid")
            return redirect('/newStaff')
        email = doc['email'][0]
        valid = checkEmail(email)
        if not valid:
            flash("Email Invalid")
            return redirect('/newStaff')
        notes = doc['notes'][0]
        payroll = doc['payroll'][0]
        status = doc['status'][0]

        # these variables need to set a new login account
        username = doc['username'][0]
        password = doc['password'][0]

        # Check if employee exists
        newStaff_cursor = new_staff_db.cursor()
        query = ("SELECT * FROM staff_info")
        newStaff_cursor.execute(query)
        result = newStaff_cursor.fetchall()
        for row in result:
            for i in row:
                if i == ssn:
                    print(i)
                    return render_template('login.html')
        #add employee
        sql = "INSERT INTO staff_info (employee_id, last_name, first_name, ssn, staff_type, address, cert, cert_expiry, phone, email, payroll, notes, status, username, password) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
        val = ('{0}',
            lastName,
            firstName,
            ssn,
            staffType,
            address,
            certification,
            certExp,
            phoneNumber,
            email,
            payroll,
            notes,
            status, 
            username,
            password)
        newStaff_cursor.execute(sql, val)

        new_staff_db.commit()   
            
        result = newStaff_cursor.fetchall()
        app.logger.info(result)
        print(result)
        for row in result:
            for i in row:
                if i:
                    return render_template('home.html')
                newStaff_cursor.close()
                new_staff_db.close()
    return render_template('newstaff.html')

@app.route("/newFile", methods=['GET', 'POST']) 

def newFile():
    
    """New File Page"""
    
    if not session.get("name"):
        return redirect('/login')
    
    if request.method == 'POST':
        doc = request.form.to_dict(flat=False)
        
        ENDPOINT = "hospitaldatabase.c9us8upioch7.us-east-1.rds.amazonaws.com"
        PORT = "3306"
        USER = "ablevy96"
        REGION = "us-east-1"
        DBNAME = "HospitalDatabase"
        os.environ['LIBMYSQL_ENABLE_CLEARTEXT_PLUGIN'] = '1'

        #connect to mysql
        client_files = pymysql.connect(
            host=ENDPOINT, user=USER,
            password="Learning613", port=3306, db=DBNAME)
        
        
        patientName = doc['lastName'][0]
        visitDate = doc['visitDate'][0]
        bed = doc['bed'][0]
        diagnosis = doc['diagnosis'][0]
        treatment = doc['treatment'][0]
        medication = doc['medication'][0]
        notes = doc['notes'][0]
        billingAmount = doc['billingAmount'][0]
        
        checkboxList = request.form.getlist('my_checkbox')
        if len(checkboxList) == 0:
            ambulanceUsed = False
        else:
            ambulanceUsed = True
            
        # Add info to database 
        sql = "INSERT INTO Files(file_id, patientName,visitDate,bed,diagnosis,treatment, medication,notes,billing, ambulance) VALUES (% s, % s, % s, % s, % s, % s, % s, % s, % s, % s);"
        data = ['{0}',
                patientName,
                visitDate,
                bed,
                diagnosis,
                treatment,
                medication,
                notes,
                billingAmount,
                ambulanceUsed]
        
        client_cur = client_files.cursor()
        client_cur.execute(sql, data)

        client_files.commit()

        result = client_cur.fetchall()
        app.logger.info(result)
        print(result)
        for row in result:
            for i in row:
                if i:
                    return render_template('home.html')
                client_files.close()
    return render_template('newFile.html')

@app.route("/search", methods=['GET', 'POST']) 
# Search Page
def search():
    if not session.get("name"):
        return redirect('/login')
    
    if request.method == 'POST':
        ENDPOINT = "hospitaldatabase.c9us8upioch7.us-east-1.rds.amazonaws.com"
        PORT = "3306"
        USER = "ablevy96"
        REGION = "us-east-1"
        DBNAME = "HospitalDatabase"
        os.environ['LIBMYSQL_ENABLE_CLEARTEXT_PLUGIN'] = '1'

        #connect to mysql
        new_staff_db = pymysql.connect(
            host=ENDPOINT, user=USER,
            password="Learning613", port=3306, db=DBNAME)
        
        doc = request.form.to_dict(flat=False)
        searchType = doc['searchType'][0]
        lastName = doc['lastName'][0]

        if (searchType == 'staff'):
            newStaff_cursor = new_staff_db.cursor()
            query = ("SELECT * FROM staff_info")
            newStaff_cursor.execute(query)
            result = newStaff_cursor.fetchall()
            testResult = ''
            staff = True
            resultsArray = []
            for row in result:
                for i in row:
                    if i == lastName:
                        testResult = row
                        resultsArray.append(testResult)
                        app.logger.info(row)
                        
            return render_template('view.html', staff = staff, resultsArray = resultsArray)
        
        if (searchType == 'records'):
            newStaff_cursor = new_staff_db.cursor()
            query = ("SELECT * FROM Files")
            newStaff_cursor.execute(query)
            result = newStaff_cursor.fetchall()
            testResult = ''
            records = True
            resultsArray = []
            for row in result:
                for i in row:
                    if i == lastName:
                        testResult = row
                        resultsArray.append(testResult)
                        app.logger.info(row)
                        
            return render_template('view.html', records = records, resultsArray = resultsArray)
        
        if (searchType == 'patients'):
            newStaff_cursor = new_staff_db.cursor()
            query = ("SELECT * FROM Patient") 
            newStaff_cursor.execute(query)
            result = newStaff_cursor.fetchall()
            testResult = ''
            patients = True
            resultsArray = []
            for row in result:
                for i in row:
                    if i == lastName:
                        testResult = row
                        resultsArray.append(testResult)
                        
            return render_template('view.html', patients = patients, resultsArray = resultsArray)


    return render_template('search.html')

@app.route('/view', methods=['GET', 'POST']) 
# View search results
def view():
    if not session.get("name"):
        return redirect('/login')
    # accept results here, then return them into the new page
    return render_template('view.html')

def checkLength(input):
    #checks the length of a field to make sure it is not too long
    valid = False
    if len(input) < 100: # can change this to a higher character value
        valid = True
    return valid

def checkNumber(input):
    #checks for a valid 0000000000 phone number
    r=re.fullmatch('[0-9][0-9]{9}',input) 
    if r!=None: 
        valid = True
    else:
        valid = False
    return valid    

def checkSSN(input):
    #checks for a valid 000000000 phone number
    r=re.fullmatch('[0-9][0-9]{8}',input) 
    if r!=None: 
        valid = True
    else:
        valid = False
    return valid 

def checkEmail(email):
    verified = False
    try:
        validate_email(email)
        verified = True
        return verified
    except:
        return verified
        
app.run(debug=True)

